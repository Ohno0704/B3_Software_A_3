public abstract class Processor {
    // add the adequate codes
    abstract Converter build();
}

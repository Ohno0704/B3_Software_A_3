import java.util.ArrayList;

public interface Statistic {
    double calc(ArrayList<Integer> data);
}